﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hospial_MVC_Example.Models
{
    public class Student
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
    }
}